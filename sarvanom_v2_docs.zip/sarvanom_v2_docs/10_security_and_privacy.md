# 10 — Security & Privacy

## HTTP & App
- Trusted hosts, CSP/HSTS, Referrer-Policy
- Rate limiting, circuit breakers, input/output sanitization
- Auth pathways (JWT or session), secure cookies if applicable

## Secrets
- Never log secrets; load only from env contract
- Rotate keys; least privilege

## Data
- Provenance stored; PII minimization; deletion on request
- Audit trails (request/response metadata, not raw prompts unless consented)
