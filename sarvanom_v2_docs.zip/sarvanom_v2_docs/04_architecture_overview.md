# 04 — Architecture Overview (Latest Stable)

## Frontend
- Next.js App Router + React, TypeScript, Tailwind (Cosmic Pro DS).  
- SSE for streaming; a11y-first.

## Backend
- FastAPI (Python 3.11+), async-first, Pydantic v2.
- Multi-lane orchestrator (web retrieval, vector, KG, synthesis), strict per-lane budgets.

## Data Layer
- **Qdrant** for vector search (dev & prod).  
- Meilisearch for keyword lanes.  
- ArangoDB for KG (optional lane but recommended).

## Observability
- Prometheus/Grafana (metrics), structured logs, trace IDs propagated to UI.

## Security
- Trusted hosts, strong security headers, input/output sanitization, rate limiting.

## Why “latest stable”?
- Choose the latest GA/stable minor versions of each framework and library at integration time. Document the exact chosen versions in the repo’s release notes.
