# SarvanOM v2 — Master Planning Pack

**Goal:** Build SarvanOM v2 in-place (no hard reset), with a new design system, strict naming and env contracts, automatic model orchestration (including multimodal), rigorous SLAs (5–10s), and full observability — while keeping naming consistent across the entire stack and using **only the latest stable tech** choices.

**How to use these docs with Cursor (high level):**
1. Start with `02_naming_conventions.md` and `03_env_contract.md`. **These are the non‑negotiable contracts.**
2. Land the design system and layout per `08_frontend_spec.md` (no business logic changes yet).
3. Implement model routing per `05_model_orchestration.md` (text + LMM), honoring `09_observability_and_budgets.md`.
4. Integrate Qdrant (dev/prod) + retrieval fabric per `06_retrieval_and_index_fabric.md` and `07_data_platform_qdrant_arango_meili.md`.
5. Add freshness feeds (news/markets) per `14_external_feeds_news_markets.md` with tight timeouts and TTLs.
6. Enforce quality gates and CI/CD per `11_ci_cd_and_quality_gates.md` and validate with `12_testing_matrix_and_playbooks.md`.
7. Clean duplicates/unreferenced files per `13_repo_hygiene_and_migrations.md`.
8. Ship, observe, iterate — use `16_operations_runbook.md` daily.

**Non-negotiables:**
- Do **not** rename existing `.env` keys. Where necessary, introduce **aliases** but keep the canonical key identical to v1.
- Do **not** invent new variable names without adding them to `03_env_contract.md` first.
- Use the same names everywhere (APIs, UI labels, logs, metrics): e.g., always **`top_k`**, never `limit`.
- Prefer “latest stable” releases of frameworks and models; if unsure, pick the highest stable major/minor and document it in `04_architecture_overview.md`.
- All provider/model additions must follow the auto‑upgrade policy in `05_model_orchestration.md`.

**Domain & hosting:**
- Primary domain: **sarvanom.com** (purchased from Namecheap). See `15_deployment_and_dns.md` for setup and hardening.

**Quick Index:**
- 01 Project Charter
- 02 Naming Conventions (contract)
- 03 Environment Contract (canonical keys + aliases)
- 04 Architecture Overview (latest stable picks)
- 05 Model Orchestration (auto-switch + auto-upgrade policy)
- 06 Retrieval & Index Fabric (budgets + fusion)
- 07 Data Platform: Qdrant/Arango/Meili (dev & prod)
- 08 Frontend Spec (per-page components; Cosmic Pro)
- 09 Observability & Budgets (SLOs, metrics, tracing)
- 10 Security & Privacy (headers, secrets, data policy)
- 11 CI/CD & Quality Gates (merge blockers)
- 12 Testing Matrix & Playbooks (manual + automated)
- 13 Repo Hygiene & Migrations (duplicates, unused)
- 14 External Feeds (news + stocks/mutual funds, free tiers)
- 15 Deployment & DNS (sarvanom.com)
- 16 Operations Runbook (daily ops)
