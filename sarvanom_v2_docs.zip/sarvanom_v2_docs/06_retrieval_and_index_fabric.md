# 06 — Retrieval & Index Fabric

## Lanes (run in parallel, fuse results)
- **Keyword:** Meilisearch
- **Vector:** Qdrant
- **KG Expansion:** ArangoDB (entities/relations)
- **Web:** Free web sources under strict timeouts
- **Freshness:** News/Markets feeds (see doc 14)

## Budgets (v2 SLOs)
- Global deadline: 5s / 7s / 10s by mode.
- Per-lane budgets are derived from mode and shrunk as time elapses.
- On timeout: mark lane `timed_out=true`, return partials.

## Fusion
- Reciprocal Rank Fusion or similar; domain diversity + recency boosts.
- De‑duplicate by domain + title + hash similarity.

## Citations
- Sentence‑to‑passage alignment; inline markers [1], [2].
- Bibliography with metadata; disagreement flagged.

## Observability
- Per-lane `p50/p95`, error/timeout counters, budget utilization.
