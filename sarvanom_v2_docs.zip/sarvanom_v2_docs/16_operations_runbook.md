# 16 — Operations Runbook

## Daily
- Check SLO dashboards, error budgets, model success rates, lane health.
- Review freshness feeds status (news/markets).

## Incidents
- ID via alerts (SLO dip, rising timeouts, provider failure).
- Mitigation: reduce parallelism, switch models/providers, raise caching TTLs.

## Weekly
- Model discovery scan; run shadow evals; consider canary upgrades.
