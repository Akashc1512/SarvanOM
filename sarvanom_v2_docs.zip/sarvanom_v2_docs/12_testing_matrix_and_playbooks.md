# 12 — Testing Matrix & Playbooks

## Matrix (examples)
- Modes × Providers × Models × Lanes (Web/Vector/KG/LLM/LMM) × Budgets (5/7/10s)
- Inputs: simple fact, coding task, literature review, image + question
- Expected: grounded answer, citations, partials if timeouts

## Playbooks
- Model regression → rollback to previous default
- Lane outage → reduce parallelism, show partials
- Provider rate-limit → backoff + switch provider
