# 11 — CI/CD & Quality Gates

## Merge Blockers
- Lint/Type checks pass
- Unit/integration tests pass
- A11y checks pass
- Performance budgets met (TTFT and E2E per mode)
- No new env keys without `03_env_contract.md` update
- Visual diffs (key pages) approved

## Branch Strategy
- `main` protected; feature branches with small PRs
- Feature flags for risky changes (e.g., new models)

## Releases
- Changelog with versions of “latest stable” adopted
