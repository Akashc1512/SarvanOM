# 09 — Observability & Budgets

## SLOs (per mode)
- Simple: 5s E2E
- Technical: 7s E2E
- Research/Multimedia: 10s E2E
- TTFT target: ~1–1.5s

## Required Metrics
- `deadline_ms`, `lane_budget_ms` per lane
- `ttft_ms`, `finalize_ms`, `answered_under_slo`
- Lane timeouts and partial flags
- Model choices: provider, model_id, mode

## Tracing
- Propagate `trace_id` to UI, logs, metrics, SSE.

## Dashboards
- SLO compliance, lane P95, timeouts, model success rates.
