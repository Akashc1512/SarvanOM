# 14 — External Feeds (News + Markets)

## News (free-friendly options)
- The Guardian Open Platform (free tier)
- GNews (free tier limits)
- NewsData.io (free tier)
- Others if available in your region

**Contract:** Normalize to { title, summary, url, source, published_at } and display “time since” in UI. Per-provider timeout ≤ ~1.2s; cache TTL 2–5 min.

## Markets (stocks / mutual funds)
- Alpha Vantage (free API key; throttled)
- Finnhub (free tier limits)
- MFAPI (mutual funds; region-specific; rate limits apply)

**Contract:** Normalize to { symbol/scheme, value, timestamp, source }. Cache TTL 15–60s. Respect rate limits; degrade gracefully.
