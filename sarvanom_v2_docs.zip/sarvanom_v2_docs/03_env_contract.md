# 03 — Environment Contract

**Rule #1:** Do **not** rename existing keys from v1. The `.env` in the repo is the **source of truth**.  
**Rule #2:** When adding new keys, document them here and ensure defaults/safe fallbacks.  
**Rule #3:** If a v1 key had synonym usage, implement a temporary **alias** but standardize everywhere to the canonical key.

## Known Keys (observed from v1 logs)
- `OPENAI_API_KEY`
- `ANTHROPIC_API_KEY`
- `HUGGINGFACE_API_TOKEN`
- `OLLAMA_BASE_URL`
- `MEILI_MASTER_KEY`
- `ARANGODB_URL`, `ARANGODB_USERNAME`, `ARANGODB_PASSWORD`, `ARANGODB_DATABASE`
- `QDRANT_URL`, `QDRANT_API_KEY` (if applicable)
- `VECTOR_COLLECTION_NAME`
- **Budgets/SLA related** (from v1): `SLA_GLOBAL_MS`, `SLA_ORCHESTRATOR_RESERVE_MS`, `SLA_LLM_MS`, `SLA_WEB_MS`, `SLA_VECTOR_MS`, `SLA_KG_MS`, `SLA_YT_MS`, `SLA_TTFT_MAX_MS`, `MODE_DEFAULT`
- **Retrieval**: `GLOBAL_SEARCH_TIMEOUT_MS`, provider-specific timeouts

> Cursor Task: Parse the actual `.env` and verify these names exist; if additional keys are present, append them to this document under “Discovered Keys” with a short description. No renames.

## New v2 Keys (add only if missing; confirm before commit)
- `MODEL_AUTO_UPGRADE_ENABLED` (true/false)
- `MODEL_DISCOVERY_CRON` (e.g., weekly)
- `LANE_BUDGET_SIMPLE_MS` (default 5000)
- `LANE_BUDGET_TECHNICAL_MS` (default 7000)
- `LANE_BUDGET_RESEARCH_MS` (default 10000)
- `LANE_BUDGET_MULTIMEDIA_MS` (default 10000)

## Aliases & Deprecations
- If `limit` appears anywhere, treat it as an alias for `top_k` and log a deprecation warning. Replace usage progressively.
