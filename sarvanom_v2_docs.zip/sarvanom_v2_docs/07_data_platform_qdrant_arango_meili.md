# 07 — Data Platform (Qdrant / Arango / Meili)

## Qdrant (Dev & Prod)
- Single source for vectors.  
- Collections per domain; payload indexes for filters.  
- Warmup on startup; connection pooling.

## Meilisearch
- Keyword search; language support; relevance tuning per domain.

## ArangoDB (KG)
- Optional but recommended; secure auth; warm queries on boot.

## Ingest Path (high level)
- Parse → clean → embed → upsert (Qdrant) + index text (Meili) + KG enrich (Arango).
- Backpressure and retries; idempotent upserts.

## Data Governance
- TTL for stale content; re‑crawl cadence; provenance stored alongside records.
