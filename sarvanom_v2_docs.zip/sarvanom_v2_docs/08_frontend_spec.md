# 08 — Frontend Specification (Cosmic Pro)

## Global
- App shell with Header + optional Sidebar + Content.
- Theme: Dark/Light with tokens; reduced-motion support; a11y AA+.

## Pages & Components (high level spec)

### 1) Landing
- Hero (left content, right mock dashboard tile)
- KPI row (3 cards: ops/sec, latency, cost)
- Features grid, CTAs

### 2) Search (root)
- Search bar with mode pills (All/Web/Vector/KG/Comprehensive)
- Answer pane (streaming + inline citations)
- Sources sidebar (live health states; details per source)
- Lane status chips with timers and “timed out” badge

### 3) Comprehensive Query (Research Composer)
- Objective + Constraints + Output format
- Evidence table (claim, confidence, disagreement, actions)
- Bibliography with export hints (no code)
- Tabs: Evidence / Analysis / Bibliography / Export

### 4) Analytics
- 6 KPI cards (trend indicators)
- 2×2 charts (provider breakdown, lane usage, errors/timeouts, incidents)
- Time range selector

### 5) Knowledge Graph
- 3 panes: Controls / Graph Canvas / Details
- Filters, node type toggles, sliders for max nodes/edges
- Node details with source references

### 6) Multimodal Upload
- Dropzone, queue with progress, ingest toggles (Qdrant/Meili/KG)
- Query box to ask about uploaded content

### 7) Blog / 8) Auth / 9) Showcase / 10) Admin
- Card grids, centered auth forms with glass morphism, feature flags dashboard, health tiles, danger zone.

## Components (primitives)
- Button, Card, Input, TextArea, Select, Tabs, Badge, Tooltip, Modal, Skeleton, Alert.

## States
- Loading skeletons, error banners, partials badge, empty states.

## Acceptance
- Uses only DS tokens/components; no raw colors; keyboard paths; Lighthouse ≥ AA.
