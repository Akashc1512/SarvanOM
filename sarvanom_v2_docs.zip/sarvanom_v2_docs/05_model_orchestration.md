# 05 — Model Orchestration (Auto‑Select & Auto‑Upgrade)

## Goals
- Pick the **best** latest stable model for the user’s query (text or multimodal), within the 5/7/10s budgets.
- Prefer lower-cost options when quality is similar.
- Support provider fallback and partials on timeouts.

## Capability Matrix (examples, not exhaustive)
- **Text‑only:** openai, anthropic, huggingface, ollama, local_stub
- **Multimodal (LMM):** openai (vision), others where available locally or via providers
- **Tool use / structured outputs:** when available, but only if stable

## Selection Heuristics
1) Classify query as `simple`, `technical`, `research`, or `multimedia`.
2) For `multimedia`, pick an **LMM** with vision/audio features.
3) Rank eligible models by: capability → latency SLO fit → cost → reliability (recent health).
4) Apply lane budgets (min of lane_budget and remaining deadline).
5) If model fails or times out, fallback to next best; render partials with a clear badge.

## Auto‑Upgrade Policy
- **Discovery:** Periodic catalog refresh from each provider.
- **Eligibility:** Only models marked **stable/GA** by providers.
- **Shadow Eval:** Route X% of traffic (e.g., 1–5%) for evaluation (non-user impacting).
- **Canary:** Promote to 10–20% after passing correctness/latency/cost thresholds.
- **Full Rollout:** Replace default after meeting SLOs for N days.
- **Rollback:** Immediate on regression alarms; keep last‑known‑good as standby.

## Configuration
- Controlled by env flags in `03_env_contract.md` (no hardcoded names).
- All decisions logged with `trace_id`, `provider`, `model_id`, `mode`, `ttft_ms`, `finalize_ms`.

## Multimodal Trigger Signals
- Image/file present or query includes phrases like “show/diagram/chart/image”.  
- UI can nudge: “Use LMM” toggle; router can still override if unsupported.

## Safety
- Enforce max context and rate limits by provider; degrade gracefully.
