# 02 — Naming Conventions (Contract)

**This is the single source of truth for parameter, metric, and UI labels.**

## Canonical Parameter Names
Use these names **exactly** across API, UI, logs, metrics, and config:
- `top_k` (never: limit, k, topk)
- `temperature`
- `max_tokens`
- `seed`
- `system_prompt`
- `user_prompt`
- `provider` (e.g., openai, anthropic, huggingface, ollama, local_stub)
- `model_id` (full provider model id)
- `model_family` (e.g., gpt-4o, claude-3, llama-3)
- `mode` (`simple`, `technical`, `research`, `multimedia`)
- `deadline_ms` (global request deadline)
- `lane_budget_ms` (per-lane budget; see budgets doc)
- `ttft_ms` (time to first token)
- `finalize_ms` (time to final token / completion)
- `answered_under_slo` (boolean)
- `citations_count`
- `disagreement_detected` (boolean)

## Response Fields (minimum set)
- `answer_stream` (SSE stream)
- `citations` (array of {id, source, url, passage, published_at})
- `lane_metrics` (per lane timings + timeouts)
- `trace_id` (end-to-end id)

## Forbidden Synonyms (replace everywhere)
- `limit`, `k`, `count` → **`top_k`**
- `deadline`, `timeout` → **`deadline_ms`**
- `budget`, `lane_timeout` → **`lane_budget_ms`**
- `first_byte` → **`ttft_ms`**

## Versioning
- Additive only; deprecations require a 2‑cycle grace period and an alias.
