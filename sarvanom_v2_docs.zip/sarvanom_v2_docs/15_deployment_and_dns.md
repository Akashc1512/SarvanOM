# 15 — Deployment & DNS (sarvanom.com)

## Domain
- Registrar: Namecheap (sarvanom.com).
- DNS: set A/AAAA to your ingress/load balancer.
- Use TLS (Let’s Encrypt) and HSTS.

## Environments
- Dev: staging subdomain
- Prod: root domain + www

## Hardening
- Security headers, strict origins, monitored cert renewal.
