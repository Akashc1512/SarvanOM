# 13 — Repo Hygiene & Migrations

## Duplicate/Unused Files Cleanup (surgical)
1) Generate a table of candidates (path, why unused, safe-to-remove Y/N).
2) Move “maybe useful” to `/deprecated/README.md` with rationale.
3) No deletions without an approved table in the PR description.

## Migrations
- Rename `limit` → `top_k` at API edges, keep alias temporarily.
- Consolidate duplicated components; map to DS primitives.
- Document every breaking change.
