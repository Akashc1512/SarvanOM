# 01 — Project Charter (SarvanOM v2)

## Mission
Deliver a “universal knowledge” assistant that is fast, grounded (citations + disagreement), and delightful — meeting strict 5–10s end-to-end SLOs and automatically selecting the best **latest stable** model for each query (including multimodal).

## Success Criteria
- **SLOs**: TTFT target ≤ ~1–1.5s; end-to-end ≤ 5s (Simple), 7s (Technical), 10s (Research/Multimedia).
- **Evidence**: ≥1 inline citation per major answer claim; disagreements flagged.
- **Routing**: Automatic model selection (text / LMM), provider fallback, cost-aware.
- **Observability**: Per-lane budgets, timeouts → partials, traceable via dashboards.
- **Consistency**: Canonical names and env keys used end-to-end (no synonyms).

## Scope (v2)
- New design system and layouts (Cosmic Pro) without breaking routes.
- Model orchestration for text + LMM with auto‑upgrade policy.
- Qdrant in dev/prod; Meili and Arango supported lanes.
- Freshness feeds for news and markets (free-tier friendly; vendor-neutral).
- CI/CD with merge gates, a11y, and performance budgets.

## Non-Goals (v2)
- No experimental libraries without documented stable status.
- No renaming of env keys or parameters outside approved alias plan.
